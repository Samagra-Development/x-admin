import { concatAST } from "graphql";
import { CandidateList } from "./candidate-profile";
import { CandidateShow } from "./candidate-show";

  
export {
    CandidateList,
    CandidateShow
}
// export  const CandidateS_how = CandidateShow;
// export const Candidate_List = CandidateList;


  